#include "userprog/process.h"
#include <debug.h>
#include <inttypes.h>
#include <round.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "userprog/gdt.h"
#include "userprog/pagedir.h"
#include "userprog/tss.h"
#include "filesys/directory.h"
#include "filesys/file.h"
#include "filesys/filesys.h"
#include "threads/flags.h"
#include "threads/init.h"
#include "threads/interrupt.h"
#include "threads/palloc.h"
#include "threads/thread.h"
#include "threads/vaddr.h"
#include "threads/malloc.h"
#include "threads/synch.h"


static thread_func start_process NO_RETURN;
static bool load (const char *cmdline, void (**eip) (void), void **esp);
static bool setup_stack (void **esp, const char *file_name);

struct load_info {
    const char *file_name;
    struct semaphore sema;
    bool load_success;
};
/* Starts a new thread running a user program loaded from
   FILENAME.  The new thread may be scheduled (and may even exit)
   before process_execute() returns.  Returns the new process's
   thread id, or TID_ERROR if the thread cannot be created. */


tid_t
process_execute (const char *file_name) 
{
    char *fn_copy;
    tid_t tid;

    struct child_info *child = malloc(sizeof(struct child_info));
    if (child == NULL) {
        return TID_ERROR;
    }
    
    sema_init(&child->load_sema, 0);
    child->load_success = false;

    fn_copy = palloc_get_page(PAL_ZERO);
    if (fn_copy == NULL){
        free(child);
        return TID_ERROR;
    }
    strlcpy(fn_copy, file_name, PGSIZE);

    char thread_name[16];
    strlcpy(thread_name, file_name, sizeof(thread_name));
    char *save_ptr;
    strtok_r(thread_name, " ", &save_ptr);

    struct exec_info {
        const char *file_name;
        struct child_info *child;
    };
    struct exec_info exec_data;
    exec_data.file_name = fn_copy;
    exec_data.child = child;

    tid = thread_create(thread_name, PRI_DEFAULT, start_process, &exec_data);

    if (tid == TID_ERROR) {
        palloc_free_page(fn_copy);
        free(child);
        return TID_ERROR;
    }
    
    child->tid = tid;
    sema_init(&child->wait_sema, 0);
    child->is_exited = false;
    child->is_waited_on = false;

    lock_acquire(&thread_current()->child_lock);
    list_push_back(&thread_current()->children, &child->elem); //추가
    lock_release(&thread_current()->child_lock);

    sema_down(&child->load_sema);

    palloc_free_page(fn_copy);

    if (!child->load_success) {
        // list_remove(&child->elem);
        // free(child);
        return TID_ERROR;
    }

    return tid;
}
/* A thread function that loads a user process and starts it
   running. */
static void
start_process (void *exec_info_)
{
    struct exec_info {
        const char *file_name;
        struct child_info *child;
    };
    struct exec_info *exec_data = exec_info_;
    const char *file_name = exec_data->file_name;
    struct child_info *child = exec_data->child;

    struct thread *cur = thread_current();
    struct intr_frame if_;
    bool success = false;

    cur->cp = child; 

    memset (&if_, 0, sizeof if_);
    if_.cs = SEL_UCSEG;
    if_.ds = SEL_UDSEG;
    if_.es = SEL_UDSEG;
    if_.ss = SEL_UDSEG;
    if_.eflags = FLAG_MBS | FLAG_IF;

    cur->fd_table = palloc_get_page(PAL_ZERO);
    if (cur->fd_table == NULL) {
        goto done; 
    }

    char file_name_copy[128];
    strlcpy(file_name_copy, file_name, sizeof(file_name_copy));
    char *save_ptr;
    char *executable_name = strtok_r(file_name_copy, " ", &save_ptr);
    
    success = load(executable_name, &if_.eip, &if_.esp);
    if (success) {
        success = setup_stack(&if_.esp, file_name);
    }
    
done:
    //palloc_free_page((void*)file_name); 
    child->load_success = success;
    sema_up(&child->load_sema);

    if (!success) {
        cur->exit_status = -1;
        thread_exit();
    }
    
    asm volatile ("movl %0, %%esp; jmp intr_exit" : : "g" (&if_) : "memory");
    NOT_REACHED ();
}

/* Waits for thread TID to die and returns its exit status.  If
   it was terminated by the kernel (i.e. killed due to an
   exception), returns -1.  If TID is invalid or if it was not a
   child of the calling process, or if process_wait() has already
   been successfully called for the given TID, returns -1
   immediately, without waiting.

   This function will be implemented in problem 2-2.  For now, it
   does nothing. */
int
process_wait (tid_t child_tid) 
{
    struct thread *cur = thread_current();
    struct child_info *child = NULL;
    lock_acquire(&cur->child_lock);
    struct list_elem *e;

    
    for (e = list_begin(&cur->children); e != list_end(&cur->children); e = list_next(e)) {
        struct child_info *temp = list_entry(e, struct child_info, elem);
        if (temp->tid == child_tid) {
            child = temp;
            break;
        }
    }

    if (child == NULL || child->is_waited_on) {
      lock_release(&cur->child_lock);
        return -1;
    }
    child->is_waited_on = true;

    lock_release(&cur->child_lock);

    sema_down(&child->wait_sema);

    // lock_acquire(&cur->child_lock);
    // list_remove(&child->elem);
    // lock_release(&cur->child_lock);

    int status = child->exit_status;
    
    //free(child);

    return status;
}

/* Free the current process's resources. */
void
process_exit (void)
{
  struct thread *cur = thread_current ();
  uint32_t *pd;

  printf("%s: exit(%d)\n", cur->name, cur->exit_status);

    if (cur->cp != NULL) {
        struct child_info *cp = cur->cp;
        cp->is_exited = true;
        cp->exit_status = cur->exit_status;
        sema_up(&cp->wait_sema);
    }
  if (cur->running_file != NULL) {
      file_allow_write(cur->running_file);
      file_close(cur->running_file);
  }  
  if (cur->fd_table != NULL) {
      for (int i = 2; i < cur->next_fd; i++) { 
          if (cur->fd_table[i] != NULL) {
              file_close(cur->fd_table[i]);
          }
      }
      palloc_free_page(cur->fd_table);
  }  

  lock_acquire(&cur->child_lock);
  while (!list_empty(&cur->children)) {
        struct list_elem *e = list_pop_front(&cur->children);
        struct child_info *child = list_entry(e, struct child_info, elem);
        free(child);
  }  
  lock_release(&cur->child_lock);

  
  /* Destroy the current process's page directory and switch back
     to the kernel-only page directory. */
  pd = cur->pagedir;
  if (pd != NULL) 
    {
      /* Correct ordering here is crucial.  We must set
         cur->pagedir to NULL before switching page directories,
         so that a timer interrupt can't switch back to the
         process page directory.  We must activate the base page
         directory before destroying the process's page
         directory, or our active page directory will be one
         that's been freed (and cleared). */
      cur->pagedir = NULL;
      pagedir_activate (NULL);
      pagedir_destroy (pd);
    }
}

/* Sets up the CPU for running user code in the current
   thread.
   This function is called on every context switch. */
void
process_activate (void)
{
  //printf("DEBUG TRACE: process_activate()\n");
  struct thread *t = thread_current ();

  /* Activate thread's page tables. */
  pagedir_activate (t->pagedir);

  /* Set thread's kernel stack for use in processing
     interrupts. */
  tss_update ();
}

/* We load ELF binaries.  The following definitions are taken
   from the ELF specification, [ELF1], more-or-less verbatim.  */

/* ELF types.  See [ELF1] 1-2. */
typedef uint32_t Elf32_Word, Elf32_Addr, Elf32_Off;
typedef uint16_t Elf32_Half;

/* For use with ELF types in printf(). */
#define PE32Wx PRIx32   /* Print Elf32_Word in hexadecimal. */
#define PE32Ax PRIx32   /* Print Elf32_Addr in hexadecimal. */
#define PE32Ox PRIx32   /* Print Elf32_Off in hexadecimal. */
#define PE32Hx PRIx16   /* Print Elf32_Half in hexadecimal. */

/* Executable header.  See [ELF1] 1-4 to 1-8.
   This appears at the very beginning of an ELF binary. */
struct Elf32_Ehdr
  {
    unsigned char e_ident[16];
    Elf32_Half    e_type;
    Elf32_Half    e_machine;
    Elf32_Word    e_version;
    Elf32_Addr    e_entry;
    Elf32_Off     e_phoff;
    Elf32_Off     e_shoff;
    Elf32_Word    e_flags;
    Elf32_Half    e_ehsize;
    Elf32_Half    e_phentsize;
    Elf32_Half    e_phnum;
    Elf32_Half    e_shentsize;
    Elf32_Half    e_shnum;
    Elf32_Half    e_shstrndx;
  };

/* Program header.  See [ELF1] 2-2 to 2-4.
   There are e_phnum of these, starting at file offset e_phoff
   (see [ELF1] 1-6). */
struct Elf32_Phdr
  {
    Elf32_Word p_type;
    Elf32_Off  p_offset;
    Elf32_Addr p_vaddr;
    Elf32_Addr p_paddr;
    Elf32_Word p_filesz;
    Elf32_Word p_memsz;
    Elf32_Word p_flags;
    Elf32_Word p_align;
  };

/* Values for p_type.  See [ELF1] 2-3. */
#define PT_NULL    0            /* Ignore. */
#define PT_LOAD    1            /* Loadable segment. */
#define PT_DYNAMIC 2            /* Dynamic linking info. */
#define PT_INTERP  3            /* Name of dynamic loader. */
#define PT_NOTE    4            /* Auxiliary info. */
#define PT_SHLIB   5            /* Reserved. */
#define PT_PHDR    6            /* Program header table. */
#define PT_STACK   0x6474e551   /* Stack segment. */

/* Flags for p_flags.  See [ELF3] 2-3 and 2-4. */
#define PF_X 1          /* Executable. */
#define PF_W 2          /* Writable. */
#define PF_R 4          /* Readable. */


static bool validate_segment (const struct Elf32_Phdr *, struct file *);
static bool load_segment (struct file *file, off_t ofs, uint8_t *upage,
                          uint32_t read_bytes, uint32_t zero_bytes,
                          bool writable);

/* Loads an ELF executable from FILE_NAME into the current thread.
   Stores the executable's entry point into *EIP
   and its initial stack pointer into *ESP.
   Returns true if successful, false otherwise. */
bool
load (const char *file_name, void (**eip) (void), void **esp) 
{
  //printf("DEBUG TRACE: load()\n");
  struct thread *t = thread_current ();
  struct Elf32_Ehdr ehdr;
  struct file *file = NULL;
  off_t file_ofs;
  bool success = false;
  int i;
  //printf("DEBUG: load started for '%s'\n", file_name);
  /* Allocate and activate page directory. */

  t->pagedir = pagedir_create ();
  if (t->pagedir == NULL){
    //printf("DEBUG: pagedir_create failed\n");
    goto done;
  }
  //printf("DEBUG: Parsed file name is: '%s'\n", parsed_file_name);
  process_activate ();

  /* Open executable file. */
  file = filesys_open (file_name);
  if (file == NULL) 
    {
      printf ("load: %s: open failed\n", file_name);
      goto done; 
    }
  t->running_file = file;
  file_deny_write(file);


  /* Read and verify executable header. */
  if (file_read (file, &ehdr, sizeof ehdr) != sizeof ehdr
      || memcmp (ehdr.e_ident, "\177ELF\1\1\1", 7)
      || ehdr.e_type != 2
      || ehdr.e_machine != 3
      || ehdr.e_version != 1
      || ehdr.e_phentsize != sizeof (struct Elf32_Phdr)
      || ehdr.e_phnum > 1024) 
    {
      //printf ("load: %s: error loading executable\n", file_name);
      goto done; 
    }

  /* Read program headers. */
  file_ofs = ehdr.e_phoff;
  //printf("DEBUG: Reading %d program headers\n", ehdr.e_phnum);
  for (i = 0; i < ehdr.e_phnum; i++) 
    {
      struct Elf32_Phdr phdr;

      if (file_ofs < 0 || file_ofs > file_length (file))
        goto done;
      file_seek (file, file_ofs);

      if (file_read (file, &phdr, sizeof phdr) != sizeof phdr)
        goto done;
      file_ofs += sizeof phdr;
      switch (phdr.p_type) 
        {
        case PT_NULL:
        case PT_NOTE:
        case PT_PHDR:
        case PT_STACK:
        default:
          /* Ignore this segment. */
          break;
        case PT_DYNAMIC:
        case PT_INTERP:
        case PT_SHLIB:
          goto done;
        case PT_LOAD:
          //printf("DEBUG: Loading segment %d\n", i);
          if (validate_segment (&phdr, file)) 
            {
              bool writable = (phdr.p_flags & PF_W) != 0;
              uint32_t file_page = phdr.p_offset & ~PGMASK;
              uint32_t mem_page = phdr.p_vaddr & ~PGMASK;
              uint32_t page_offset = phdr.p_vaddr & PGMASK;
              uint32_t read_bytes, zero_bytes;
              if (phdr.p_filesz > 0)
                {
                  /* Normal segment.
                     Read initial part from disk and zero the rest. */
                  read_bytes = page_offset + phdr.p_filesz;
                  zero_bytes = (ROUND_UP (page_offset + phdr.p_memsz, PGSIZE)
                                - read_bytes);
                }
              else 
                {
                  /* Entirely zero.
                     Don't read anything from disk. */
                  read_bytes = 0;
                  zero_bytes = ROUND_UP (page_offset + phdr.p_memsz, PGSIZE);
                }
              if (!load_segment (file, file_page, (void *) mem_page,
                                 read_bytes, zero_bytes, writable)){
                //printf("DEBUG: load_segment failed\n");
                goto done;
                }
            }
          else{
            //printf("DEBUG: validate_segment failed\n");
            goto done;
          }
          break;
        }
    }

  // /* Set up stack. */
  // if (!setup_stack (esp, file_name))
  //   goto done;

  /* Start address. */
  *eip = (void (*) (void)) ehdr.e_entry;
  success = true;

 done:
  /* We arrive here whether the load is successful or not. */
  //printf("DEBUG: load returning %s\n", success ? "true" : "false"); 
    if (!success && file != NULL) {
        file_close(file);
        t->running_file = NULL;
    }
  return success;
}

/* load() helpers. */

static bool install_page (void *upage, void *kpage, bool writable);

/* Checks whether PHDR describes a valid, loadable segment in
   FILE and returns true if so, false otherwise. */
static bool
validate_segment (const struct Elf32_Phdr *phdr, struct file *file) 
{
  /* p_offset and p_vaddr must have the same page offset. */
  if ((phdr->p_offset & PGMASK) != (phdr->p_vaddr & PGMASK)) 
    return false; 

  /* p_offset must point within FILE. */
  if (phdr->p_offset > (Elf32_Off) file_length (file)) 
    return false;

  /* p_memsz must be at least as big as p_filesz. */
  if (phdr->p_memsz < phdr->p_filesz) 
    return false; 

  /* The segment must not be empty. */
  if (phdr->p_memsz == 0)
    return false;
  
  /* The virtual memory region must both start and end within the
     user address space range. */
  if (!is_user_vaddr ((void *) phdr->p_vaddr))
    return false;
  if (!is_user_vaddr ((void *) (phdr->p_vaddr + phdr->p_memsz)))
    return false;

  /* The region cannot "wrap around" across the kernel virtual
     address space. */
  if (phdr->p_vaddr + phdr->p_memsz < phdr->p_vaddr)
    return false;

  /* Disallow mapping page 0.
     Not only is it a bad idea to map page 0, but if we allowed
     it then user code that passed a null pointer to system calls
     could quite likely panic the kernel by way of null pointer
     assertions in memcpy(), etc. */
  if (phdr->p_vaddr < PGSIZE)
    return false;

  /* It's okay. */
  return true;
}

/* Loads a segment starting at offset OFS in FILE at address
   UPAGE.  In total, READ_BYTES + ZERO_BYTES bytes of virtual
   memory are initialized, as follows:

        - READ_BYTES bytes at UPAGE must be read from FILE
          starting at offset OFS.

        - ZERO_BYTES bytes at UPAGE + READ_BYTES must be zeroed.

   The pages initialized by this function must be writable by the
   user process if WRITABLE is true, read-only otherwise.

   Return true if successful, false if a memory allocation error
   or disk read error occurs. */
static bool
load_segment (struct file *file, off_t ofs, uint8_t *upage,
              uint32_t read_bytes, uint32_t zero_bytes, bool writable) 
{
  ASSERT ((read_bytes + zero_bytes) % PGSIZE == 0);
  ASSERT (pg_ofs (upage) == 0);
  ASSERT (ofs % PGSIZE == 0);

  file_seek (file, ofs);
  while (read_bytes > 0 || zero_bytes > 0) 
    {
      /* Calculate how to fill this page.
         We will read PAGE_READ_BYTES bytes from FILE
         and zero the final PAGE_ZERO_BYTES bytes. */
      size_t page_read_bytes = read_bytes < PGSIZE ? read_bytes : PGSIZE;
      size_t page_zero_bytes = PGSIZE - page_read_bytes;

      /* Get a page of memory. */
      uint8_t *kpage = palloc_get_page (PAL_USER);
      if (kpage == NULL)
        return false;

      /* Load this page. */
      if (file_read (file, kpage, page_read_bytes) != (int) page_read_bytes)
        {
          palloc_free_page (kpage);
          return false; 
        }
      memset (kpage + page_read_bytes, 0, page_zero_bytes);

      /* Add the page to the process's address space. */
      if (!install_page (upage, kpage, writable)) 
        {
          palloc_free_page (kpage);
          return false; 
        }

      /* Advance. */
      read_bytes -= page_read_bytes;
      zero_bytes -= page_zero_bytes;
      upage += PGSIZE;
    }
  return true;
}

/* Create a minimal stack by mapping a zeroed page at the top of
   user virtual memory. */
static bool
setup_stack (void **esp, const char *file_name) 
{
  char *fn_copy;
  char *token, *save_ptr;
  char *argv[128];
  int argc = 0;
  int i;

  fn_copy = palloc_get_page (PAL_ZERO);

  if (fn_copy == NULL){
    return false;
  }
  strlcpy (fn_copy, file_name, PGSIZE);

  for (token = strtok_r(fn_copy, " ", &save_ptr); token != NULL;
         token = strtok_r(NULL, " ", &save_ptr)) {
        argv[argc++] = token;
  }
  uint8_t *kpage;
  bool success = false;
  kpage = palloc_get_page (PAL_USER | PAL_ZERO);

  if (kpage != NULL) 
    {
      success = install_page (((uint8_t *) PHYS_BASE) - PGSIZE, kpage, true);
      if (success)
      {
        *esp = PHYS_BASE;

        for(i = argc - 1; i >= 0; i--) {
          *esp -= (strlen(argv[i]) + 1);
          memcpy(*esp, argv[i], strlen(argv[i]) + 1);
          argv[i] = *esp; 
        }

        while ((int)*esp % 4 != 0) {
          *esp -= 1;
          *(uint8_t *)*esp = 0;
        }

        *esp -= 4; 
        *(void **)*esp = NULL;

        for(i = argc - 1; i >= 0; i--) {
          *esp -= 4;
          *(char **)*esp = argv[i];
        }

        void *argv_ptr = *esp;
        *esp -= 4;
        *(void **)*esp = argv_ptr;

        *esp -= 4;
        *(int*)*esp = argc;

        *esp -= 4;
        *(void**)*esp = 0;
      }
      else{
        palloc_free_page (kpage);
      }
        
    }
  
  palloc_free_page (fn_copy);
  return success;
}

/* Adds a mapping from user virtual address UPAGE to kernel
   virtual address KPAGE to the page table.
   If WRITABLE is true, the user process may modify the page;
   otherwise, it is read-only.
   UPAGE must not already be mapped.
   KPAGE should probably be a page obtained from the user pool
   with palloc_get_page().
   Returns true on success, false if UPAGE is already mapped or
   if memory allocation fails. */
static bool
install_page (void *upage, void *kpage, bool writable)
{
  //printf("DEBUG TRACE: install_page()\n");
  struct thread *t = thread_current ();

  /* Verify that there's not already a page at that virtual
     address, then map our page there. */
  return (pagedir_get_page (t->pagedir, upage) == NULL
          && pagedir_set_page (t->pagedir, upage, kpage, writable));
}
