#ifndef USERPROG_SYSCALL_H
#define USERPROG_SYSCALL_H

#include <list.h>
#include "threads/synch.h"


void syscall_init (void);
int fibonacci(int n);
int max_of_four_int(int a, int b, int c, int d);
void exit(int status);



extern struct lock filesys_lock;

struct map_elem {
    int mapid;
    void *addr;
    int size; 
    struct list_elem elem;
};

#endif /* userprog/syscall.h */
